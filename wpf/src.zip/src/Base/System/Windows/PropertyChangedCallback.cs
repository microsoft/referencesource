namespace System.Windows
{
    /// <summary>
    ///     Property change notification callback
    /// </summary>
    public delegate void PropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e);
}

