namespace System.Windows
{
    /// <summary>
    ///     Validate property value
    /// </summary>
    public delegate bool ValidateValueCallback(object value);
}

