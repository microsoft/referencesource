//------------------------------------------------------------------------------
//  Microsoft Avalon
//  Copyright (c) Microsoft Corporation, 2001
//
//  File:       precomp.hxx
//------------------------------------------------------------------------------

#define WIN32_LEAN_AND_MEAN


#include <wpfsdl.h>
#include <windows.h>
#include <StrSafe.h>
#include <intsafe.h>
#include <stdlib.h>


#using WINDOWS_BASE_DLL as_friend

