//+-----------------------------------------------------------------------------
//  
//  Copyright (C) Microsoft Corporation
//  
//  File: ttmem.cpp
//
//  Description:    
//      Routines to allocate and free memory.
//
//  History:
//      02/12/2004 MLeonov
//          Created it.
//
//------------------------------------------------------------------------------

#include "typedefs.h"

#include "ttmem.h"

#include "fsassert.h"

using namespace System::Security;
using namespace System::Security::Permissions;

// <SecurityNote>
//  Critical - allocates native mem and returns a pointer to it.
// </SecurityNote>
[SecurityCritical]
[SecurityPermission(SecurityAction::Assert, UnmanagedCode = true)]
void * Mem_Alloc(size_t size)
{
    return calloc(1, size);
}


// <SecurityNote>
//  Critical - Frees an arbitrary native pointer.
// </SecurityNote>
[SecurityCritical]
[SecurityPermission(SecurityAction::Assert, UnmanagedCode = true)]
void Real_Mem_Free(void * pv)
{
    free (pv);
}


// Mem_Free/Mem_Alloc are expensive in partial trust. More than half of the calls to Mem_Free are 
// with NULL pointers. So we check for NULL pointer before going into expensive assert and interop.
// There are more optimizations possible (for example grouping Mem_Alloc calls). But this is safe.
// <SecurityNote>
//  Critical - Frees an arbitrary native pointer.
// </SecurityNote>
[SecurityCritical]
void Mem_Free(void * pv)
{
    if (pv != NULL)
    {
        Real_Mem_Free(pv);
    }        
}


// <SecurityNote>
//  Critical - allocates native mem and returns a pointer to it.
// </SecurityNote>
[SecurityCritical]
[SecurityPermission(SecurityAction::Assert, UnmanagedCode = true)]
void * Mem_ReAlloc(void * base, size_t newSize)
{
    return realloc(base, newSize);
}

int16 Mem_Init(void)
{
    return MemNoErr;
}

void Mem_End(void)
{
}

